package models;

public enum VarType {
    VOID, INT, CHAR
}
