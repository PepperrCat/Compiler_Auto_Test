package error;

public enum ErrorType {
    //a-m
    a, b, c, d, e, f, g, h, i, j, k, l, m
}
