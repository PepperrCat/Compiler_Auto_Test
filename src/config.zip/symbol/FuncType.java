package symbol;

public enum FuncType {
    VOID, INT,CHAR

}
