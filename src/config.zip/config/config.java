package config;

public class config {
    public static String inputPath = "testfile.txt";
    public static String laxerOutputPath = "laxerOutput.txt";
    public static String parserOutputPath = "output.txt";
    public static String errorOutputPath = "error.txt";
    public static boolean debug = false;

    public static boolean laxer = true;

    public static boolean parser = true;
    public static boolean error = true;

}
