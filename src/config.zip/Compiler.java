
import Nodes.CompUnitNode;
import error.ErrorAnalyze;
import front.Laxer;
import front.Parser;

import java.io.IOException;

public class Compiler {
    public static void main(String[] args) throws IOException, IllegalAccessException {
        Laxer.analyze();

        CompUnitNode compUnitNode = Parser.startAnalyze();

        ErrorAnalyze.errorEnalyze(compUnitNode);

    }
}
